# PetSense AI

A responsive web prototype for **Universal Elastic Pet Belt: AI-Powered Multi-Species Monitoring and Smart Care System**. PetSense AI presents a species-aware companion dashboard that turns illustrative wearable signals into approachable behavior and care insights.

> **Prototype status:** This repository contains the browser-based demonstration interface. Pet profiles, sensor readings, emotion states, and care suggestions are sample/demo data. It is not connected to a physical belt, live sensor hardware, Firebase, a trained AI model, or production GPS services, and it does not provide veterinary diagnosis.

## Features

- Multi-species demo profiles for dogs, cats, rabbits, birds, and reptiles
- Species-specific emotion demonstration with distinct signal cues
- Digital twin style overview with wellbeing, mood, activity, and risk indicators
- Behavioral interpretation, appetite and hydration estimates, and care suggestions
- AI insights, interactive life timeline, habitat intelligence, and care studio
- Veterinary conversation summary with browser print-to-PDF
- Responsive desktop and mobile layouts
- Dark appearance interface

## Technologies

- HTML5 for page structure
- CSS3 for responsive layouts, visual effects, and themes
- Vanilla JavaScript for demo data, profile switching, navigation, and interactions
- Google Fonts (DM Sans and Manrope), loaded online by the page

No framework installation, API keys, or build step is required to run the demo.

## Run locally

1. Download or clone this repository.
2. Open index.html in a modern browser.

For a local development server, open the folder in Visual Studio Code and use the Live Server extension, or run Python's built-in server from this directory:

    python -m http.server 8000

Then visit http://localhost:8000.

## Project files

- index.html — page structure and app entry point
- app.js — profiles, demo states, interpretation copy, navigation, and UI interactions
- styles.css — main layout and component styling
- pet-avatar.css — species avatar presentation
- emotion-demo.css — emotion demo controls
- pet-palette.css — color palette and appearance styling
- emotion-visuals.css — emotion visualization styling

## Demo use

Use the pet selector to switch between species profiles. Choose **Emotion demo** to select an example emotion and view the corresponding species-specific signal interpretation. The displayed values are illustrative and should not be used to make health decisions.

## Future integration

A production system could connect this interface to a belt device, validated species-specific models, secure cloud storage, authentication, maps, and notifications. Those services are not implemented in this prototype.